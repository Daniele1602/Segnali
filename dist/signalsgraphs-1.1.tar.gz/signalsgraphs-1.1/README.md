# Package for signal modulation graphic representations

Pacchetto contenente delle funzioni per la rappresentazione grafica dei segnali.<br/>
Istruzione di import: "from Signals import signal"

Version 1.0<br/>
Methods:
<ul>
    <li>amsignal(am, ap, fm, fp, mostraSpettro)</li>
    <li>spettro(am, ap, fm, fp)</li>
    <li>max(*args)</li>
</ul>